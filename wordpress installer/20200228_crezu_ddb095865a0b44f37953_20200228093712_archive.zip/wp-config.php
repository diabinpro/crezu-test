<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', '' );


/** Имя пользователя MySQL */
define( 'DB_USER', '' );


/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );


/** Имя сервера MySQL */
define( 'DB_HOST', '' );


/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );


/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'NJV~lNuP_J-fo`De5:Q:jjZ^Z;-M-&]D=y:{cI{MfSIjUC=@+#xHjJ3SYVXI*fZU' );

define( 'SECURE_AUTH_KEY',  'mB|#7yZS^YEQ>RMnv{c=cH:okpQSM0jDGQ4,wz4t/1|O!FgQGMrKz*~)x:/gaij,' );

define( 'LOGGED_IN_KEY',    '?x1a_Qu|&>C&3|AaKfjgy<zL6]a}k.P56)f5.gZSkAMgjLCC)^FG8%$5=7$u{aWd' );

define( 'NONCE_KEY',        're(]f@f,SrC<zSackt iZ^$.(pp`eR5e2s>ikj-!#^U/|{v-o:ZvpXeoUmLFFf`/' );

define( 'AUTH_SALT',        '[b49AwIq9yNkfed {qA9eg8c6i L^Qe,z/0/~a&rh*G%ef4vWQU_2F>b@AjZ v:V' );

define( 'SECURE_AUTH_SALT', 'efZX}}D%2,De]IgsGd$Y_q0i?b{_AfE|3Gma2!+CUOK:R*#F=c?kMrbqRY[.C)(A' );

define( 'LOGGED_IN_SALT',   '&ND.gJd7N|5kNCzGKHsnu%:Cp:L?p347MJEE.+Nr?!hMU1[>FV?ua57E)$=SOX@#' );

define( 'NONCE_SALT',       'AgW:p+.f-025ctAlW7[I|U,i~C,$qnWIML&h3{bKa!v1x&lRi{X*IIP8{gKT~$$^' );


/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';


/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
